from __future__ import annotations

import logging

from typing import Any, Dict, List, Optional

from fastapi import HTTPException, status

from database.conversation_repository import (

    create_conversation as db_create_conversation,

    get_conversations as db_get_conversations,

    get_conversation as db_get_conversation,

    update_conversation_title as db_update_title,

    delete_conversation as db_delete_conversation,

    save_message as db_save_message,

    get_messages as db_get_messages,

)

from database.supabase_client import get_supabase

logger = logging.getLogger(__name__)

def get_user_profile(user_id: str) -> Dict[str, Any]:
    supabase = get_supabase()

    result = (

        supabase.table("user_profiles")

        .select("user_id, company_id, role, full_name")

        .eq("user_id", user_id)

        .limit(1)

        .execute()

    )

    if not result.data:
        raise HTTPException(

            status_code=status.HTTP_404_NOT_FOUND,

            detail="User profile not found. Please ensure account setup is complete.",

        )

    return result.data[0]

def get_user_company_id(user_id: str) -> Optional[str]:
    try:
        profile = get_user_profile(user_id)

        return profile.get("company_id")

    except HTTPException:
        return None

def get_user_role(user_id: str) -> str:
    try:
        profile = get_user_profile(user_id)

        return profile.get("role", "employee")

    except HTTPException:
        return "employee"

def require_knowledge_admin(user_id: str) -> None:
    role = get_user_role(user_id)

    if role != "knowledge_admin":
        raise HTTPException(

            status_code=status.HTTP_403_FORBIDDEN,

            detail="This action requires the Knowledge Admin role.",

        )

async def create_conversation(

    user_id: str,

    title: str = "New Conversation",

) -> Dict[str, Any]:
    company_id = get_user_company_id(user_id)

    conv = db_create_conversation(

        user_id=user_id,

        company_id=company_id,

        title=title,

    )

    logger.info("Conversation created: id=%s user=%s", conv["id"], user_id)

    return conv

async def list_conversations(user_id: str) -> List[Dict[str, Any]]:
    return db_get_conversations(user_id=user_id)

async def get_conversation(

    conversation_id: str,

    user_id: str,

) -> Dict[str, Any]:
    conv = db_get_conversation(conversation_id, user_id)

    if not conv:
        raise HTTPException(

            status_code=status.HTTP_404_NOT_FOUND,

            detail="Conversation not found.",

        )

    return conv

async def update_conversation_title(

    conversation_id: str,

    user_id: str,

    title: str,

) -> Dict[str, Any]:
    await get_conversation(conversation_id, user_id)

    db_update_title(conversation_id, user_id, title)

    return {"conversation_id": conversation_id, "title": title}

async def delete_conversation(

    conversation_id: str,

    user_id: str,

) -> None:
    await get_conversation(conversation_id, user_id)

    db_delete_conversation(conversation_id, user_id)

async def append_message(

    conversation_id: str,

    user_id: str,

    role: str,

    content: str,

    sources: Optional[List[Dict[str, Any]]] = None,

) -> Dict[str, Any]:
    await get_conversation(conversation_id, user_id)

    if role not in ("user", "assistant"):
        raise HTTPException(

            status_code=status.HTTP_400_BAD_REQUEST,

            detail=f"Invalid role '{role}'. Must be 'user' or 'assistant'.",

        )

    msg = db_save_message(

        conversation_id=conversation_id,

        user_id=user_id,

        role=role,

        content=content,

        sources=sources,

    )

    return msg

async def get_messages(

    conversation_id: str,

    user_id: str,

    limit: int = 100,

) -> List[Dict[str, Any]]:
    msgs = db_get_messages(conversation_id, user_id, limit)

    return msgs

async def get_conversation_history_for_llm(

    conversation_id: str,

    user_id: str,

    limit: int = 20,

) -> List[Dict[str, str]]:
    msgs = await get_messages(conversation_id, user_id, limit)

    history = []

    for msg in msgs:
        llm_role = "model" if msg["role"] == "assistant" else "user"

        history.append({"role": llm_role, "parts": [msg["content"]]})

    return history
