from __future__ import annotations

import logging

from typing import List, Dict, Any, Optional

from database.supabase_client import get_supabase

logger = logging.getLogger(__name__)

TABLE = "document_chunks"

def save_chunks(

    chunks: List[Dict[str, Any]],

    document_id: str,

    user_id: str,

    category: str = "General",

    scope: str = "company",

    company_id: Optional[str] = None,

) -> List[Dict[str, Any]]:
    if not chunks:
        return []

    rows = [

        {

            "document_id": document_id,

            "user_id":     user_id,

            "chunk_index": chunk["chunk_index"],

            "chunk_text":  chunk["chunk_text"],

            "page_number": chunk.get("page_number"),

            "token_count": chunk.get("token_count"),

            "category":    category,

            "scope":       scope,

            "company_id":  company_id,

        }

        for chunk in chunks

    ]

    supabase = get_supabase()

    result = supabase.table(TABLE).insert(rows).execute()

    if not result.data:
        raise RuntimeError(

            f"Failed to insert chunks for document {document_id}: "

            "Supabase returned no data."

        )

    logger.info(

        "Saved %d chunks for doc %s (scope=%s) to Supabase",

        len(result.data), document_id, scope,

    )

    return result.data

def get_chunks(

    document_id: str,

    limit: int = 500,

) -> List[Dict[str, Any]]:
    supabase = get_supabase()

    result = (

        supabase.table(TABLE)

        .select("*")

        .eq("document_id", document_id)

        .order("chunk_index", desc=False)

        .limit(limit)

        .execute()

    )

    return result.data or []

def delete_chunks(document_id: str) -> int:
    supabase = get_supabase()

    count_result = (

        supabase.table(TABLE)

        .select("id", count="exact")

        .eq("document_id", document_id)

        .execute()

    )

    count = count_result.count if hasattr(count_result, "count") else 0

    supabase.table(TABLE).delete().eq("document_id", document_id).execute()

    logger.info("Deleted %d chunks for doc %s", count, document_id)

    return count or 0

def get_chunk_count_for_user(user_id: str) -> int:
    supabase = get_supabase()

    result = (

        supabase.table(TABLE)

        .select("id", count="exact")

        .eq("user_id", user_id)

        .execute()

    )

    return result.count if hasattr(result, "count") and result.count else 0

def get_chunk_counts_per_document(

    document_ids: List[str],

) -> Dict[str, int]:
    if not document_ids:
        return {}

    supabase = get_supabase()

    result = (

        supabase.table(TABLE)

        .select("document_id")

        .in_("document_id", document_ids)

        .execute()

    )

    counts: Dict[str, int] = {}

    for row in (result.data or []):
        doc_id = row["document_id"]

        counts[doc_id] = counts.get(doc_id, 0) + 1

    return counts
