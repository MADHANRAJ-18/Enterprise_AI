from __future__ import annotations

import logging

from typing import List

from graph.state import AgentState, RetrievedChunk, Citation, append_to_path, chunks_to_citations

logger = logging.getLogger(__name__)

async def citation_node(state: AgentState) -> AgentState:
    state = append_to_path(state, "citation")

    chunks: List[RetrievedChunk] = state.get("retrieved_chunks", [])

    if not chunks:
        logger.info("Citation: no chunks — returning empty citations")

        return {**state, "citations": []}

    citations: List[Citation] = chunks_to_citations(chunks)

    logger.info(

        "Citation: extracted %d unique citations from %d chunks",

        len(citations), len(chunks),

    )

    for cit in citations:
        logger.debug(

            "  [%d] %s | page=%s | scope=%s | score=%.3f",

            cit["source_index"],

            cit["file_name"],

            cit.get("page", "—"),

            cit.get("scope", "company"),

            cit.get("score", 0.0),

        )

    return {**state, "citations": citations}
